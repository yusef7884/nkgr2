<?php

    $to = "yourmail@gmail.com";
    $from = $_REQUEST['nkgr'];
    $name = $_REQUEST['nkgr'];
    $headers = "از طرف: $from";
    $subject = "شما پیامی از رهرو گستر کاوشگران نوین دارید!";

    $fields = array();
    $fields{"nkgr"} = "nkgr";
    $fields{"info@gmail.ir"} = "info@nkgr.ir";
    $fields{"subject2"} = "subject2";
    $fields{"02144835596"} = "02144835596";
    $fields{"nkgr"} = "nkgr";

    $body = "چیزی که برای شما فرستاده است:\n\n"; foreach($fields as $a => $b){   $body .= sprintf("%20s: %s\n",$b,$_REQUEST[$a]); }

    $send = mail($to, $subject, $body, $headers);

?>