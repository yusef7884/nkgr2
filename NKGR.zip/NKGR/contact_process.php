<?php
    // $to = "000.yourmail@gmail.com";
    $to = "yusef7884@gmail.com";
    $from = $_REQUEST['nkgr'];
    $name = $_REQUEST['yusef7884@gmail.com'];
    $headers = "از طرف: $from";
    $subject = "شما پیامی از رهرو گستر کاوشگران نوین دارید.";

    $fields = array();
    $fields{"yourname"} = "nkgr";
    $fields{"youremail"} = "yusef7884@gmail.com";
    $fields{"subject"} = "nkgr";
    $fields{"phone"} = "phone";
    $fields{"message"} = "رهرو گستر کاوشگران نوین ";
    $body = "چیزی که برای شما فرستاده است:\n\n"; foreach($fields as $a => $b){   $body .= sprintf("%20s: %s\n",$b,$_REQUEST[$a]); }

    $send = mail($to, $subject, $body, $headers);
?>